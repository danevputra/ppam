<?php

include("koneksi.php");

$id_user = $_POST['id_user'];
$longitude = $_POST['long'];
$latitude = $_POST['lat'];

if($id_user && $longitude && $latitude){
    $stmt = $conn->prepare("INSERT INTO `sos`(`id_user`, `longitude`, `latitude`) VALUES (?,?,?)");
    $stmt->bind_param("sss",$id_user,$longitude,$latitude);
    
    if($stmt->execute() == TRUE){
        $response['error'] = false;
        $response['message'] = "SOS Terkirim";
    } else{
        $response['error'] = true;
        $response['message'] = "failed\n ".$conn->error;
    }

} else{
	$response['error'] = true;
	$response['message'] = "Data tidak lengkap";
}
// at last we are prinintg our response which we get.
echo json_encode($response);

?>