-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2021 at 06:02 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homecare`
--

-- --------------------------------------------------------

--
-- Table structure for table `jenis_oksigen`
--

CREATE TABLE `jenis_oksigen` (
  `id_jenis` int(11) NOT NULL,
  `ukuran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jenis_oksigen`
--

INSERT INTO `jenis_oksigen` (`id_jenis`, `ukuran`) VALUES
(1, 500),
(2, 1000),
(3, 1500),
(4, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `oxymeter`
--

CREATE TABLE `oxymeter` (
  `id_oxy` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oxymeter`
--

INSERT INTO `oxymeter` (`id_oxy`, `id_user`, `image_name`, `timestamp`) VALUES
(1, 3, '61af311112ac5.png', '2021-12-07 10:01:53'),
(2, 3, '3_61af36bdc13dd.png', '2021-12-07 10:26:05'),
(3, 7, '7_61af39de21887.png', '2021-12-07 10:39:26'),
(4, 3, '3_61b2ccf0b0fdb.png', '2021-12-10 03:43:44'),
(5, 7, '7_61b2e244b77a8.png', '2021-12-10 05:14:44'),
(6, 7, '7_61bb6514c821b.png', '2021-12-16 16:11:00'),
(7, 2, '2_61bb695440cc3.png', '2021-12-16 16:29:08');

-- --------------------------------------------------------

--
-- Table structure for table `pesan_obat`
--

CREATE TABLE `pesan_obat` (
  `id_obat` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `pesanan` varchar(500) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pesan_obat`
--

INSERT INTO `pesan_obat` (`id_obat`, `id_user`, `pesanan`, `timestamp`) VALUES
(1, 1, 'ivermectin, Favipiravir', '2021-12-10 05:11:04'),
(2, 7, 'ivermectin, rendesivir', '2021-12-10 05:12:31'),
(3, 7, 'apa aja nihh', '2021-12-10 05:14:03'),
(4, 7, 'panadol', '2021-12-16 16:09:04'),
(5, 2, 'bodrex', '2021-12-16 16:28:44');

-- --------------------------------------------------------

--
-- Table structure for table `pesan_oksigen`
--

CREATE TABLE `pesan_oksigen` (
  `id_oksi` int(11) NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pesan_oksigen`
--

INSERT INTO `pesan_oksigen` (`id_oksi`, `id_jenis`, `id_user`, `timestamp`) VALUES
(1, 1, 2, '2021-12-10 04:11:24'),
(2, 1, 7, '2021-12-10 04:35:30'),
(3, 2, 7, '2021-12-10 04:35:38'),
(4, 3, 7, '2021-12-10 04:35:42'),
(5, 3, 7, '2021-12-10 04:35:47'),
(6, 4, 7, '2021-12-10 04:35:53'),
(7, 1, 7, '2021-12-10 05:14:16'),
(8, 2, 7, '2021-12-10 05:14:22'),
(9, 3, 7, '2021-12-10 05:14:26'),
(10, 4, 7, '2021-12-10 05:14:30'),
(11, 3, 7, '2021-12-16 16:10:39'),
(12, 4, 2, '2021-12-16 16:28:53');

-- --------------------------------------------------------

--
-- Table structure for table `sos`
--

CREATE TABLE `sos` (
  `id_sos` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sos`
--

INSERT INTO `sos` (`id_sos`, `id_user`, `longitude`, `latitude`, `timestamp`) VALUES
(1, 3, '3.4567', '2.4789', '2021-11-11 16:38:56'),
(2, 3, '3.4567', '2.4789', '2021-12-04 15:12:40'),
(3, 7, '110.44699455021295', '-7.009009009009009', '2021-12-04 15:17:27'),
(4, 7, '110.44699455021295', '-7.009009009009009', '2021-12-04 15:20:43'),
(5, 7, '110.44699455021295', '-7.009009009009009', '2021-12-04 15:20:54'),
(6, 3, '0.0', '0.0', '2021-12-10 03:43:18'),
(7, 7, '0.0', '0.0', '2021-12-10 05:13:38'),
(8, 7, '0.0', '0.0', '2021-12-10 05:13:44'),
(9, 7, '110.44699455021295', '-7.009009009009009', '2021-12-10 05:13:52'),
(10, 7, '0.0', '0.0', '2021-12-16 16:06:18'),
(11, 7, '110.44699455021295', '-7.009009009009009', '2021-12-16 16:06:30'),
(12, 2, '110.44699455021295', '-7.009009009009009', '2021-12-16 16:28:31');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`, `alamat`) VALUES
(1, 'daniel evan', 'daniel@gmail.com', 'daniel', '202cb962ac59075b964b07152d234b70', 'jl sesuatu'),
(2, 'daniel ev', 'daniel2@gmail.com', 'daniele', '202cb962ac59075b964b07152d234b70', 'jl apa yaa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jenis_oksigen`
--
ALTER TABLE `jenis_oksigen`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `oxymeter`
--
ALTER TABLE `oxymeter`
  ADD PRIMARY KEY (`id_oxy`);

--
-- Indexes for table `pesan_obat`
--
ALTER TABLE `pesan_obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `pesan_oksigen`
--
ALTER TABLE `pesan_oksigen`
  ADD PRIMARY KEY (`id_oksi`);

--
-- Indexes for table `sos`
--
ALTER TABLE `sos`
  ADD PRIMARY KEY (`id_sos`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jenis_oksigen`
--
ALTER TABLE `jenis_oksigen`
  MODIFY `id_jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `oxymeter`
--
ALTER TABLE `oxymeter`
  MODIFY `id_oxy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pesan_obat`
--
ALTER TABLE `pesan_obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pesan_oksigen`
--
ALTER TABLE `pesan_oksigen`
  MODIFY `id_oksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sos`
--
ALTER TABLE `sos`
  MODIFY `id_sos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
