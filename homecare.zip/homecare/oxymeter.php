<?php
    include("koneksi.php");

    $response = array();
	define('UPLOAD_DIR', 'images/');
    $img = $_POST['img'];
    $id_user = $_POST['id'];
	$img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file_name = $id_user.'_'.uniqid() . '.png';
	$file = UPLOAD_DIR . $file_name;
    $success = file_put_contents($file, $data);
    
    if($success){
        $sql = "INSERT INTO oxymeter (id_user,image_name) VALUES ($id_user, '$file_name')";
        if (mysqli_query($conn, $sql)){
            $response['error'] = false;
            $response['message'] = "Gambar Terupload";
        }
        else{
            $response['error'] = true;
            $response['message'] = "Gambar gagal Terupload";
        }
    }
    else{
        $response['error'] = true;
        $response['message'] = "Gambar gagal Terupload";
    }

    echo json_encode($response);
?>