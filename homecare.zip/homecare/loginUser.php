<?php

include("koneksi.php");

$response = array();

$username = $_POST['username'];
$password = md5($_POST['password']);

if($username && $password){
    $data = mysqli_query($conn, "SELECT * FROM user WHERE username='$username' AND password='$password' LIMIT 1");
    $cek = mysqli_num_rows($data);
    $id = mysqli_fetch_array($data);

    if ($cek > 0){
        $response['error'] = false;
        $response['message'] = "User ada";
        $response['id'] = $id['id_user'];
    }

    else {
        $response['error'] = true;
	    $response['message'] = "Username atau Password Salah";
    }
}
echo json_encode($response);
?>