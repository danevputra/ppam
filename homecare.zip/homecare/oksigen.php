<?php

include("koneksi.php");

$response = array();

$jenis = $_POST['jenis'];
$user = $_POST['user'];

if($jenis && $user){

    $stmt = $conn->prepare("INSERT INTO `pesan_oksigen`(`id_jenis`, `id_user`) VALUES (?,?)");
    $stmt->bind_param("ss",$jenis,$user);

    if($stmt->execute() == TRUE){
        $response['error'] = false;
        $response['message'] = "Pemesanan berhasil!";
    } else{
        $response['error'] = true;
        $response['message'] = "failed\n ".$conn->error;
    }

} else{
	$response['error'] = true;
	$response['message'] = "Data tidak lengkap";
}
// at last we are prinintg our response which we get.
echo json_encode($response);
?>
