<?php

include("koneksi.php");

$response = array();

$pesanan = $_POST['pesanan'];
$user = $_POST['user'];

if($pesanan && $user){

    $stmt = $conn->prepare("INSERT INTO `pesan_obat`(`id_user`, `pesanan`) VALUES (?,?)");
    $stmt->bind_param("ss",$user,$pesanan);

    if($stmt->execute() == TRUE){
        $response['error'] = false;
        $response['message'] = "Pemesanan berhasil!";
    } else{
        $response['error'] = true;
        $response['message'] = "failed\n ".$conn->error;
    }

} else{
	$response['error'] = true;
	$response['message'] = "Data tidak lengkap";
}
// at last we are prinintg our response which we get.
echo json_encode($response);
?>
