<?php

include("koneksi.php");

$response = array();

$nama = $_POST['nama'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = md5($_POST['password']);
$alamat = $_POST['alamat'];

if($nama && $email && $username && $password && $alamat){

    $data = mysqli_query($conn, "SELECT * FROM user WHERE username='$username'");
    $cek = mysqli_num_rows($data);

    if ($cek > 0){
        $response['error'] = true;
	    $response['message'] = "Username Tersebut Telah Terdaftar";
    }

    else{
        $stmt = $conn->prepare("INSERT INTO `user`(`nama`, `email`, `username`, `password`, `alamat`) VALUES (?,?,?,?,?)");
        $stmt->bind_param("sssss",$nama,$email,$username,$password,$alamat);
    
    if($stmt->execute() == TRUE){
            $response['error'] = false;
            $response['message'] = "Pendaftaran berhasil!";
        } else{
            $response['error'] = true;
            $response['message'] = "failed\n ".$conn->error;
        }
    }

} else{
	$response['error'] = true;
	$response['message'] = "Data tidak lengkap";
}
// at last we are prinintg our response which we get.
echo json_encode($response);
?>
